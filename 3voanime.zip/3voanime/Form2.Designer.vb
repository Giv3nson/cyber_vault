﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        TextBox4 = New TextBox()
        TextBox5 = New TextBox()
        TextBox6 = New TextBox()
        TextBox7 = New TextBox()
        Button1 = New Button()
        PictureBox3 = New PictureBox()
        PictureBox4 = New PictureBox()
        PictureBox5 = New PictureBox()
        PictureBox6 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = SystemColors.ActiveCaption
        PictureBox1.Location = New Point(0, -1)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(235, 455)
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Cursor = Cursors.No
        PictureBox2.Image = My.Resources.Resources.cover1
        PictureBox2.Location = New Point(12, 18)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(206, 187)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' TextBox1
        ' 
        TextBox1.Cursor = Cursors.Help
        TextBox1.Font = New Font("Courier New", 14.25F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        TextBox1.ForeColor = Color.Maroon
        TextBox1.Location = New Point(12, 220)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(206, 29)
        TextBox1.TabIndex = 2
        TextBox1.Text = "Home"
        TextBox1.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox2
        ' 
        TextBox2.Cursor = Cursors.Help
        TextBox2.Font = New Font("Courier New", 14.25F, FontStyle.Bold Or FontStyle.Italic)
        TextBox2.Location = New Point(12, 258)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(206, 29)
        TextBox2.TabIndex = 3
        TextBox2.Text = "Games"
        TextBox2.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox3
        ' 
        TextBox3.Cursor = Cursors.Help
        TextBox3.Font = New Font("Courier New", 14.25F, FontStyle.Bold Or FontStyle.Italic)
        TextBox3.Location = New Point(12, 296)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(206, 29)
        TextBox3.TabIndex = 4
        TextBox3.Text = "Rewards"
        TextBox3.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox4
        ' 
        TextBox4.Cursor = Cursors.Help
        TextBox4.Font = New Font("Courier New", 14.25F, FontStyle.Bold Or FontStyle.Italic)
        TextBox4.Location = New Point(12, 335)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(206, 29)
        TextBox4.TabIndex = 5
        TextBox4.Text = "Achievements"
        TextBox4.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox5
        ' 
        TextBox5.Cursor = Cursors.Help
        TextBox5.Font = New Font("Courier New", 14.25F, FontStyle.Bold Or FontStyle.Italic)
        TextBox5.Location = New Point(12, 373)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(206, 29)
        TextBox5.TabIndex = 6
        TextBox5.Text = "Latest News"
        TextBox5.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox6
        ' 
        TextBox6.Cursor = Cursors.Help
        TextBox6.Font = New Font("Courier New", 14.25F, FontStyle.Bold Or FontStyle.Italic)
        TextBox6.Location = New Point(12, 409)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(206, 29)
        TextBox6.TabIndex = 7
        TextBox6.Text = "Settings"
        TextBox6.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox7
        ' 
        TextBox7.BorderStyle = BorderStyle.None
        TextBox7.Cursor = Cursors.Hand
        TextBox7.Font = New Font("Courier New", 24F, FontStyle.Bold Or FontStyle.Italic)
        TextBox7.Location = New Point(241, 18)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(180, 37)
        TextBox7.TabIndex = 8
        TextBox7.Text = "3voAnime"
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Transparent
        Button1.Cursor = Cursors.AppStarting
        Button1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(333, 388)
        Button1.Name = "Button1"
        Button1.Size = New Size(455, 31)
        Button1.TabIndex = 9
        Button1.Text = "EXIT"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Image = My.Resources.Resources.thumbnail_
        PictureBox3.Location = New Point(333, 116)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(124, 248)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 10
        PictureBox3.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Cursor = Cursors.Hand
        PictureBox4.Image = My.Resources.Resources.photo_
        PictureBox4.Location = New Point(509, 116)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(120, 248)
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox4.TabIndex = 11
        PictureBox4.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Cursor = Cursors.Hand
        PictureBox5.Image = My.Resources.Resources.nail_
        PictureBox5.Location = New Point(676, 119)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(112, 248)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 12
        PictureBox5.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Cursor = Cursors.Hand
        PictureBox6.Image = My.Resources.Resources.logo_1
        PictureBox6.Location = New Point(393, 11)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(43, 44)
        PictureBox6.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox6.TabIndex = 13
        PictureBox6.TabStop = False
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(800, 450)
        Controls.Add(PictureBox6)
        Controls.Add(PictureBox5)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(Button1)
        Controls.Add(TextBox7)
        Controls.Add(TextBox6)
        Controls.Add(TextBox5)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Name = "Form2"
        Text = "Form2"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
End Class
