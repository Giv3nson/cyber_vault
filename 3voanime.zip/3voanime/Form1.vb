﻿Public Class Form1
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox2.Text = "3voanime@co.za" And TextBox3.Text = "54321" Then
            MessageBox.Show("Welome back")
            Me.Hide()
            Form2.Show()
        Else
            MessageBox.Show("Incorrect Details, try again. ..")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If MessageBox.Show("Continue with signing up", "Confirmation", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Me.Show()
            Form3.Show()
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class
