﻿Public Class Form3
    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If MessageBox.Show("Are you sure you want to exit?", "Confirmation", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Me.Hide()
            Form1.Show()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ListBox1.Items.Add("Username : " + TextBox2.Text)
        ListBox1.Items.Add("email address : " + TextBox3.Text)
        ListBox1.Items.Add("Region : " + ComboBox1.Text)
        ListBox1.Items.Add("Cell No. : " + TextBox4.Text)
        ListBox1.Items.Add("Password : " + TextBox5.Text)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If MessageBox.Show("Create Account?", "Confirmation", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Me.Hide()
            Form2.Show()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        ListBox1.Items.Clear()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
    End Sub

    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        Dim Ch As Char = e.KeyChar
        If Not Char.IsDigit(Ch) Then
            e.Handled = True
        End If
    End Sub
End Class