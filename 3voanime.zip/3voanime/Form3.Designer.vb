﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        TextBox4 = New TextBox()
        TextBox5 = New TextBox()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        ComboBox1 = New ComboBox()
        ListBox1 = New ListBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.BorderStyle = BorderStyle.None
        TextBox1.Cursor = Cursors.No
        TextBox1.Font = New Font("Courier New", 24F, FontStyle.Bold Or FontStyle.Italic)
        TextBox1.Location = New Point(12, 28)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(163, 37)
        TextBox1.TabIndex = 0
        TextBox1.Text = "3voAnime"
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(238, 109)
        TextBox2.Name = "TextBox2"
        TextBox2.PlaceholderText = "enter username"
        TextBox2.Size = New Size(159, 23)
        TextBox2.TabIndex = 1
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(238, 172)
        TextBox3.Name = "TextBox3"
        TextBox3.PlaceholderText = "enter email address"
        TextBox3.Size = New Size(159, 23)
        TextBox3.TabIndex = 2
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(238, 291)
        TextBox4.Multiline = True
        TextBox4.Name = "TextBox4"
        TextBox4.PlaceholderText = "enter cell number"
        TextBox4.Size = New Size(159, 23)
        TextBox4.TabIndex = 3
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(238, 344)
        TextBox5.Multiline = True
        TextBox5.Name = "TextBox5"
        TextBox5.PasswordChar = "*"c
        TextBox5.PlaceholderText = "enter password"
        TextBox5.Size = New Size(159, 24)
        TextBox5.TabIndex = 4
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Cursor = Cursors.No
        PictureBox1.Image = My.Resources.Resources.logo_2
        PictureBox1.Location = New Point(169, 15)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(54, 50)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 5
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Cursor = Cursors.AppStarting
        PictureBox2.Image = My.Resources.Resources.cover2
        PictureBox2.Location = New Point(12, 85)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(194, 283)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 6
        PictureBox2.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.Location = New Point(204, 390)
        Button1.Name = "Button1"
        Button1.Size = New Size(75, 40)
        Button1.TabIndex = 7
        Button1.Text = "Verify"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.Location = New Point(309, 390)
        Button2.Name = "Button2"
        Button2.Size = New Size(75, 42)
        Button2.TabIndex = 8
        Button2.Text = "Create Account"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.Location = New Point(402, 390)
        Button3.Name = "Button3"
        Button3.Size = New Size(75, 44)
        Button3.TabIndex = 9
        Button3.Text = "Clear"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.Location = New Point(503, 390)
        Button4.Name = "Button4"
        Button4.Size = New Size(75, 44)
        Button4.TabIndex = 10
        Button4.Text = "Exit"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Items.AddRange(New Object() {"Kempton Park", "Mamelodi", "Centurion", "Midrand", "East-Lynne"})
        ComboBox1.Location = New Point(238, 233)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(159, 23)
        ComboBox1.TabIndex = 11
        ComboBox1.Text = "select region"
        ' 
        ' ListBox1
        ' 
        ListBox1.Cursor = Cursors.WaitCursor
        ListBox1.FormattingEnabled = True
        ListBox1.ItemHeight = 15
        ListBox1.Location = New Point(532, 49)
        ListBox1.Name = "ListBox1"
        ListBox1.Size = New Size(243, 319)
        ListBox1.TabIndex = 12
        ' 
        ' Form3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(800, 450)
        Controls.Add(ListBox1)
        Controls.Add(ComboBox1)
        Controls.Add(Button4)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(TextBox5)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Name = "Form3"
        Text = "Form3"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ListBox1 As ListBox
End Class
